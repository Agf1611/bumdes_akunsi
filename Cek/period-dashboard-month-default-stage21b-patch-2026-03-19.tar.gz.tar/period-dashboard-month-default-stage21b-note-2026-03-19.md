Perbaikan khusus dashboard agar default statistik membaca bulan/periode yang dipilih, bukan langsung 1 tahun penuh.

File diubah:
- app/modules/dashboard/DashboardController.php
- app/modules/dashboard/views/index.php

Perubahan:
1. Default range dashboard kembali memakai start/end dari periode yang dipilih.
2. Range 1 tahun penuh hanya dipakai fallback jika periode belum ada.
3. Teks bantuan filter diperjelas: periode default = bulan acuan utama, manual override tetap bisa dipakai.
